This code repository is solution for Assignment 6 for the course CS641.

To run the program
-------------------
run the solve.ipynb file either on jupyter notebook or on cocalc.com with SageMath9.2 as kernel.

Program Files
--------------
=> rsa.ipynb: jupyter notebook file, implementing the solution to the level.
=> padding.txt: it contains the hexadecimals found on the chambers of the game. They are used as padding in rsa.ipynb coppersmith's code.

